import pygame

class Alien(pygame.sprite.Sprite):
    def __init__(self, type, x, y):
        super().__init__()
        file_path = "assets/images/" + type + ".png"
        self.image = pygame.image.load(file_path).convert_alpha()
        self.rect = self.image.get_rect(topleft = (x, y))

        if type == "red": self.value = 100
        elif type == "green": self.value = 160
        else: self.value = 270

    def update(self, direction):
        self.rect.x += direction

class Extra(pygame.sprite.Sprite):
    def __init__(self, side, screen_width):
        super().__init__()
        self.image = pygame.image.load("assets/images/extra.png").convert_alpha()

        if side == "right":
            x = screen_width + 50
            self.speed = - 3
        else:
            x = -50
            self.speed = 3

        self.rect = self.image.get_rect(topleft = (x,20))

    def update(self):
        self.rect.x += self.speed


import pygame

class Laser(pygame.sprite.Sprite):
    def __init__(self, pos, speed, screen_height):
        super().__init__()
        self.image = pygame.transform.scale(pygame.image.load("assets/images/laserRed.png").convert_alpha(), (5, 10))
        self.rect = self.image.get_rect(center=pos)
        self.speed = speed
        self.height_y_constraint = screen_height

    def destroy(self):
        if self.rect.y <= -10:
            self.kill()

    def update(self):
        self.rect.y -= self.speed
        self.destroy()

